"""
Minimal WhatsApp auto-responder.

Flow:  Whapi webhook  ->  Claude (draft reply + importance score)  ->  reply, or alert you.

Run locally:
    pip install fastapi uvicorn httpx
    WHAPI_TOKEN=... ANTHROPIC_API_KEY=... MY_NUMBER=4915... WEBHOOK_SECRET=... DRY_RUN=true \
        uvicorn wa_bot:app --host 0.0.0.0 --port 8000

Keep DRY_RUN=true until you've watched the logs for a few days. It logs what it WOULD
send instead of sending, so you can judge the voice + the flagging before it goes live.
"""

import os
import json
import logging

import httpx
from fastapi import FastAPI, Request, Header, HTTPException

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("wa-bot")

WHAPI_TOKEN = os.environ["WHAPI_TOKEN"]
ANTHROPIC_API_KEY = os.environ["ANTHROPIC_API_KEY"]
MY_NUMBER = os.environ["MY_NUMBER"]          # where flags/alerts go, e.g. "4915123456789"
WEBHOOK_SECRET = os.environ["WEBHOOK_SECRET"]  # must match the custom header set in Whapi
WHAPI_BASE = "https://gate.whapi.cloud"
MODEL = "claude-sonnet-4-6"
DRY_RUN = os.environ.get("DRY_RUN", "true").lower() == "true"

# Optional: only auto-handle these chat ids. Empty = everyone who messages you.
ALLOWLIST = set(filter(None, os.environ.get("ALLOWLIST", "").split(",")))

# YOUR VOICE. Paste 10-20 real (them -> you) exchanges. This is the single biggest
# lever on quality — more real examples beats any prompt cleverness.
STYLE_EXAMPLES = """
Them: yo you coming friday
You: yeah for sure what time we starting
Them: can you send me that doc
You: on it gimme 10
Them: how was the run
You: brutal. legs are gone lol
"""

SYSTEM = f"""You reply to WhatsApp messages AS the user, in their exact voice.
Match tone, length, punctuation, capitalisation and slang from the examples below.
Default to SHORT.

Hard rule: never invent facts about the user's plans, schedule, location, money, or
commitments. If a good reply would require info you don't have, set "needs_user": true
and keep "reply" short and non-committal (you'll hand it to the user instead).

Also decide if this message needs the user's PERSONAL attention: anything time-sensitive,
emotionally significant, a real decision, money, conflict, or where a generic reply could
do damage. When unsure, flag it — a false flag is cheap, a missed important message is not.

The user's voice:
{STYLE_EXAMPLES}

Respond with JSON ONLY, no prose, no code fences:
{{"important": bool, "needs_user": bool, "reason": "few words", "reply": "message to send"}}"""

app = FastAPI()


async def claude(message_text: str) -> dict:
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": MODEL,
                "max_tokens": 400,
                "system": SYSTEM,
                "messages": [{"role": "user", "content": message_text}],
            },
        )
    r.raise_for_status()
    text = "".join(b["text"] for b in r.json()["content"] if b["type"] == "text")
    text = text.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
    return json.loads(text)


async def send_whatsapp(to: str, body: str):
    if DRY_RUN:
        log.info("[DRY_RUN] would send -> %s: %s", to, body)
        return
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.post(
            f"{WHAPI_BASE}/messages/text",
            headers={"Authorization": f"Bearer {WHAPI_TOKEN}"},
            json={"to": to, "body": body},
        )
    r.raise_for_status()


@app.post("/webhook")
async def webhook(req: Request, x_webhook_secret: str | None = Header(default=None)):
    # The sandbox is public, so this endpoint is open. Reject anything without the secret.
    if x_webhook_secret != WEBHOOK_SECRET:
        raise HTTPException(status_code=401, detail="bad secret")

    payload = await req.json()
    # FIRST RUN: read this log line once to confirm the real field names for your
    # channel, then trust the parsing below. Whapi's payload shape can vary slightly.
    log.info("RAW: %s", json.dumps(payload)[:2000])

    for msg in payload.get("messages", []):
        if msg.get("from_me"):
            continue  # ignore your own outgoing messages

        sender = msg.get("from") or msg.get("chat_id")
        body = msg.get("text", {}).get("body") if isinstance(msg.get("text"), dict) else msg.get("body")
        if not sender or not body:
            continue
        if ALLOWLIST and sender not in ALLOWLIST:
            continue

        try:
            out = await claude(body)
        except Exception as e:
            log.exception("claude call failed: %s", e)
            continue

        if out.get("important"):
            await send_whatsapp(MY_NUMBER, f"\u26a0\ufe0f flagged ({sender}): {out.get('reason','')}\n\n> {body}")
            continue  # you handle important ones yourself

        if out.get("needs_user"):
            await send_whatsapp(MY_NUMBER, f"\u2753 needs you ({sender}): {body}\ndraft: {out.get('reply','')}")
            continue

        await send_whatsapp(sender, out["reply"])

    return {"ok": True}
