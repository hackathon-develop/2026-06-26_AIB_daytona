"""
ONE-TIME provisioning. Run locally once to create the long-lived sandbox.
After this, CI (deploy.py) only updates code in place — the sandbox, and therefore
the webhook URL, stay fixed.

    pip install daytona
    DAYTONA_API_KEY=...  WHAPI_TOKEN=...  ANTHROPIC_API_KEY=...  \
    MY_NUMBER=4915...    WEBHOOK_SECRET=$(openssl rand -hex 16)   \
    python provision.py

Prints SANDBOX_ID (save as a GitHub secret) and the WEBHOOK URL (paste into Whapi).

NOTE ON SDK SYMBOLS: the Daytona Python SDK renames classes/params between versions.
The *concepts* below are stable (snapshot, public, auto_stop_interval=0,
get_preview_link, git clone, process exec); if an import or kwarg name is off, check
the current Python SDK reference — don't assume these spellings are frozen.
"""

import os

from daytona import Daytona, DaytonaConfig, CreateSandboxParams

REPO = os.environ.get("REPO_URL", "https://github.com/YOUR_USER/wa-bot.git")
PORT = 8000

daytona = Daytona(DaytonaConfig(api_key=os.environ["DAYTONA_API_KEY"]))

sandbox = daytona.create(CreateSandboxParams(
    snapshot="wa-bot",          # the snapshot built from Dockerfile
    public=True,                # webhook reachable without a per-request token...
    auto_stop_interval=0,       # ...and NEVER auto-stops (mandatory for a listener)
    env_vars={
        "WHAPI_TOKEN":      os.environ["WHAPI_TOKEN"],
        "ANTHROPIC_API_KEY": os.environ["ANTHROPIC_API_KEY"],
        "MY_NUMBER":        os.environ["MY_NUMBER"],
        "WEBHOOK_SECRET":   os.environ["WEBHOOK_SECRET"],  # app verifies this header
        "DRY_RUN":          "true",                        # keep true until tuned
    },
))

# Clone the app into the sandbox and start the listener.
sandbox.git.clone(REPO, "/home/daytona/app")
sandbox.process.exec(
    "cd /home/daytona/app && nohup uvicorn wa_bot:app "
    "--host 0.0.0.0 --port 8000 > /home/daytona/app.log 2>&1 &"
)
# For a more robust daemon than nohup, use Daytona "Sessions" (process.create_session)
# — see the Process Execution docs. nohup is fine for a for-fun build.

preview = sandbox.get_preview_link(PORT)
print("SANDBOX_ID :", sandbox.id)
print("WEBHOOK URL:", preview.url.rstrip("/") + "/webhook")
